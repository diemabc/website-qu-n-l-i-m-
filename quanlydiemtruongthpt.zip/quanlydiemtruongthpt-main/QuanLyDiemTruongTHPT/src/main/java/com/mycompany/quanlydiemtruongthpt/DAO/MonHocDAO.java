package com.mycompany.quanlydiemtruongthpt.DAO;

import com.mycompany.quanlydiemtruongthpt.Model.MonHoc;

public class MonHocDAO extends DAO<MonHoc> {
}
