package com.mycompany.quanlydiemtruongthpt.DAO;

import com.mycompany.quanlydiemtruongthpt.Model.TonGiao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TonGiaoDAO extends DAO<TonGiao> {

}
