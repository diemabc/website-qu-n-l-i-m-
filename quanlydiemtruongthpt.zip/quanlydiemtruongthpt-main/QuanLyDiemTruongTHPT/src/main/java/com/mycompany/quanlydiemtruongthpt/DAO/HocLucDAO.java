package com.mycompany.quanlydiemtruongthpt.DAO;

import com.mycompany.quanlydiemtruongthpt.Model.DiemHocKyMonHoc;
import com.mycompany.quanlydiemtruongthpt.Model.HocLuc;

public class HocLucDAO extends DAO<HocLuc>{
}
