package com.mycompany.quanlydiemtruongthpt.DAO;

import com.mycompany.quanlydiemtruongthpt.Model.DiemHocKyMonHoc;
import com.mycompany.quanlydiemtruongthpt.Model.HanhKiem;

public class HanhKiemDAO extends DAO<HanhKiem>{
}
