package com.mycompany.quanlydiemtruongthpt.DAO;

import com.mycompany.quanlydiemtruongthpt.Model.DiemHocKyMonHoc;
import com.mycompany.quanlydiemtruongthpt.Model.HocKy;

public class HocKyDAO extends DAO<HocKy>{
}
