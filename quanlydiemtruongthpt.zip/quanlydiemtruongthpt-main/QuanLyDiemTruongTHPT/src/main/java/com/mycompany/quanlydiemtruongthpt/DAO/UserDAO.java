package com.mycompany.quanlydiemtruongthpt.DAO;

import com.mycompany.quanlydiemtruongthpt.Model.User;

public class UserDAO extends DAO<User> {
}
