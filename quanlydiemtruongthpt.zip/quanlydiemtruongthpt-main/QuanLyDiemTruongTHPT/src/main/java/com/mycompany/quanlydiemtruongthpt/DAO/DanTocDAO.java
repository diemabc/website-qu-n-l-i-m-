package com.mycompany.quanlydiemtruongthpt.DAO;

import com.mycompany.quanlydiemtruongthpt.Model.DanToc;

public class DanTocDAO extends DAO<DanToc>{

}
