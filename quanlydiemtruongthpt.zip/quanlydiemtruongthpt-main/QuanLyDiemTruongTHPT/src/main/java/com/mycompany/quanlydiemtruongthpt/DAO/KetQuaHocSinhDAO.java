package com.mycompany.quanlydiemtruongthpt.DAO;

import com.mycompany.quanlydiemtruongthpt.Model.KetQuaHocSinh;

public class KetQuaHocSinhDAO extends DAO<KetQuaHocSinh> {
}
