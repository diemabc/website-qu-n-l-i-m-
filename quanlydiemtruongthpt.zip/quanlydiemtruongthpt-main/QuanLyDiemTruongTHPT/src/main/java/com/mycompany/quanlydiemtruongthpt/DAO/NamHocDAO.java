package com.mycompany.quanlydiemtruongthpt.DAO;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mycompany.quanlydiemtruongthpt.Connection.MyConnection;
import com.mycompany.quanlydiemtruongthpt.Model.NamHoc;

public class NamHocDAO extends DAO<NamHoc> {

}
