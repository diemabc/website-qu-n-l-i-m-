package com.mycompany.quanlydiemtruongthpt.DAO;

import com.mycompany.quanlydiemtruongthpt.Model.DiemHocKyMonHoc;
import com.mycompany.quanlydiemtruongthpt.Model.HoSoHocSinh;

public class HoSoHocSinhDAO extends DAO<HoSoHocSinh>{
}
