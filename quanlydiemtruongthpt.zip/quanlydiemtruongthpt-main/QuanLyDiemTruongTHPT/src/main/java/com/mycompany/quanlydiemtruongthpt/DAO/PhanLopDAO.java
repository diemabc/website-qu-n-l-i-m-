package com.mycompany.quanlydiemtruongthpt.DAO;

import com.mycompany.quanlydiemtruongthpt.Model.PhanLop;

public class PhanLopDAO extends DAO<PhanLop> {

}
