package com.mycompany.quanlydiemtruongthpt.DAO;

import com.mycompany.quanlydiemtruongthpt.Model.Diem;

public class DiemDAO extends DAO<Diem>{
}
