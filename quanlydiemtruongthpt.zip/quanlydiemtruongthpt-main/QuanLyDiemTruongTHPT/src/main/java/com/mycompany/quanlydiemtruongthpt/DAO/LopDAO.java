package com.mycompany.quanlydiemtruongthpt.DAO;

import com.mycompany.quanlydiemtruongthpt.Connection.MyConnection;
import com.mycompany.quanlydiemtruongthpt.Model.DanToc;
import com.mycompany.quanlydiemtruongthpt.Model.Lop;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class LopDAO extends DAO<Lop>{

}
