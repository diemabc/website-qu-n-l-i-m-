package com.mycompany.quanlydiemtruongthpt.DAO;

import com.mycompany.quanlydiemtruongthpt.Model.DiemHocKyMonHoc;

public class DiemHocKyMonHocDAO extends DAO<DiemHocKyMonHoc> {
}
