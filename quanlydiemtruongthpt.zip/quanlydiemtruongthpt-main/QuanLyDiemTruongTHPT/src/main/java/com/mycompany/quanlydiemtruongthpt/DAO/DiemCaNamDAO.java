package com.mycompany.quanlydiemtruongthpt.DAO;

import com.mycompany.quanlydiemtruongthpt.Model.DiemCaNam;

public class DiemCaNamDAO extends DAO<DiemCaNam> {
}
