package com.mycompany.quanlydiemtruongthpt.DAO;

import com.mycompany.quanlydiemtruongthpt.Model.KhoiLop;

public class KhoiLopDAO extends DAO<KhoiLop> {
}
