package com.mycompany.quanlydiemtruongthpt.DAO;

import com.mycompany.quanlydiemtruongthpt.Model.DiemHocKyMonHoc;
import com.mycompany.quanlydiemtruongthpt.Model.KetQua;

public class KetQuaDAO extends DAO<KetQua>{
}
