package com.mycompany.quanlydiemtruongthpt.DAO;

import com.mycompany.quanlydiemtruongthpt.Model.LoaiDiem;

public class LoaiDiemDAO extends DAO<LoaiDiem> {
}
