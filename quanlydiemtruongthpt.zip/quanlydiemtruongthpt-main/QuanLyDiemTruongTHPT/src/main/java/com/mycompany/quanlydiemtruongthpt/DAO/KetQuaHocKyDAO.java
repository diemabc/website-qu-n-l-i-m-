package com.mycompany.quanlydiemtruongthpt.DAO;

import com.mycompany.quanlydiemtruongthpt.Model.KetQuaHocKy;

public class KetQuaHocKyDAO extends DAO<KetQuaHocKy> {
}
