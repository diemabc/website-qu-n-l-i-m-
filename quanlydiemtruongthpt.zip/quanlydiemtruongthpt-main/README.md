# quanlydiemtruongthpt
Quản lý điểm cho học sinh trường THPT, dùng java và mysql
